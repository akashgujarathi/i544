'use strict';

const assert = require('assert');
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const querystring = require('querystring');

const Mustache = require('./mustache');
const widgetView = require('./widget-view');

const STATIC_DIR = 'statics';
const TEMPLATES_DIR = 'templates';

function serve(port, model, base = '') {
  //@TODO
  const app = express();
  app.locals.port = port;
  app.locals.base = base;
  app.locals.model = model;
  process.chdir(__dirname);
  //setupTemplates(app);
  app.use(base, express.static(STATIC_DIR));

  setupRoutes(app);
  app.listen(port, function() {
    console.log(`listening on port ${port}`);
  });
}

module.exports = serve;

//@TODO
function setupRoutes(app) {
  const base = app.locals.base;
  app.get(`${base}/sensor-types.html`, searchAll(app, 'sensor-types'));
  app.get(`${base}/sensors.html`, searchAll(app, 'sensors'));

  //app.post(`${base}/sensor-types/add.html`, addAll(app));
  //app.post(`${base}/sensors/add.html`, addAll(app));
}

/***********************Routing*************************** */
function searchAll(app, type) {
  return async function(req, res) {
    try {
      const search = getNonEmptyValues(req.query);
      const q = querystring.stringify(search);
      const result = await app.locals.model.list(type, q);
      console.log(result);
    } catch (error) {
      console.log(error);
    }
  };
}
/***********************General Utilities*************************** */
function getNonEmptyValues(values) {
  const out = {};
  Object.keys(values).forEach(function(k) {
    if (FIELDS_INFO[k] !== undefined) {
      const v = values[k];
      if (v && v.trim().length > 0) out[k] = v.trim();
    }
  });
  return out;
}
